import matplotlib.pyplot as plt
import matplotlib.colors as clrs
import numpy as np

def plotDataPoints(X, idx, K):
    #PLOTDATAPOINTS plots data points in X, coloring them so that those with the same
    #index assignments in idx have the same color
    #   PLOTDATAPOINTS(X, idx, K) plots data points in X, coloring them so that those 
    #   with the same index assignments in idx have the same color

    # Create palette
    palette = clrs.hsv_to_rgb( np.column_stack([ np.linspace(0, 1, K+1), np.ones( ((K+1), 2) ) ]) )
    colors = np.array([palette[int(i)] for i in idx])

    # Plot the data
    plt.scatter(X[:,0], X[:,1], s=75, facecolors='none', edgecolors=colors)

    return
